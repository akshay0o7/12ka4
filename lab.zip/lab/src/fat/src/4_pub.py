#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float64MultiArray
import cmath
def talker():
    pub = rospy.Publisher('chatter', Float64MultiArray, queue_size=10)

    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        a = float(input("enter a"))
        b = float(input("enter b"))
        c = float(input("enter c"))
        D= (b*b - 4*a*c)
        roots= Float64MultiArray()
        root1= (-1*b + cmath.sqrt(D))/(2*a)
        root2= (-1*b - cmath.sqrt(D))/(2*a)
        root1_img= root1.imag
        root1_real= root1.real
        root2_img= root2.imag
        root2_real= root2.real
        
        
        roots.data=[root1_real,root1_img,root2_real,root2_img] 
        pub.publish(roots)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
