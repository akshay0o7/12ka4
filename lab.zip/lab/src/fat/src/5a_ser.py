#!/usr/bin/env python3

import rospy
from fat.srv import add, addResponse

def handle_add(req):
    # Calculate the sum and product
    sum_result = req.a + req.b + req.c
    product_result = req.a * req.b * req.c

    rospy.loginfo(f"Received: a={req.a}, b={req.b}, c={req.c}")
    rospy.loginfo(f"Sum: {sum_result}, Product: {product_result}")

    # Return the response
    return addResponse(sum_result, product_result)

def sum_and_product_server():
    rospy.init_node('sum_and_product_server')
    rospy.Service('sum_and_product', add, handle_add)
    rospy.loginfo("Ready to calculate sum and product.")
    rospy.spin()

if __name__ == '__main__':
    sum_and_product_server()

