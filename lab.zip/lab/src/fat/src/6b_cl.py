#!/usr/bin/env python3
import sys
import rospy
from fat.srv import ConvertMetersToFeet

def metres_to_feet_client(x):
    rospy.loginfo("Waiting for service...")
    rospy.wait_for_service('metres_to_feet')
    try:
        metres_to_feet = rospy.ServiceProxy('metres_to_feet', ConvertMetersToFeet)
        service_response = metres_to_feet(x)
        return service_response
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == "__main__":
    rospy.init_node("metres_to_feet_client", anonymous=False)
    dist_metres = int(input("Enter conversion value"))
    rospy.loginfo(f"Requesting conversion of {dist_metres:.2f} m to feet")
    service_response = metres_to_feet_client(dist_metres)
    if not service_response.success:
        rospy.logerr("Conversion unsuccessful! Requested distance in metres should be a positive real number.")
    else:
        rospy.loginfo(f"{dist_metres:.2f} m = {service_response.distance_feet:.2f} feet")
        rospy.loginfo("Conversion successful!")

