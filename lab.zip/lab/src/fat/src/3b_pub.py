#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float64MultiArray

def talker():
    pub = rospy.Publisher('chatter', Float64MultiArray, queue_size=10)

    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        a = float(input("enter a"))
        b = float(input("enter b"))
        c = float(input("enter c"))
        root1= (-1*b + ((b*b - 4*a*c)**(1/2)))/(2*a)
        root2= (-1*b - ((b*b - 4*a*c)**(1/2)))/(2*a)
        D= (b*b - 4*a*c)
        roots= Float64MultiArray()
        roots.data=[root1,root2]
        if D<0:

        	rospy.loginfo("Non-Real roots")

        #rospy.loginfo(f"output=  {sq}")
        else :
        	pub.publish(roots)
        
        
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
