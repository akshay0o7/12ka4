#!/usr/bin/env python3

import rospy
from fat.srv import add

def sum_and_product_client(a, b, c):
    # Wait for the service to become available
    rospy.wait_for_service('sum_and_product')

    try:
        # Call the service
        sum_and_product = rospy.ServiceProxy('sum_and_product', add)
        response = sum_and_product(a, b, c)
        return response.sum_result, response.product_result
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")
        return None, None

def get_user_input(prompt):
    while True:
        try:
            value = int(input(prompt))
            return value
        except ValueError:
            print("Invalid input. Please enter an integer.")

if __name__ == '__main__':
    rospy.init_node('sum_and_product_client')

    # Get inputs from the user
    a = get_user_input("Enter first integer: ")
    b = get_user_input("Enter second integer: ")
    c = get_user_input("Enter third integer: ")

    # Call the service and display results
    sum_result, product_result = sum_and_product_client(a, b, c)
    if sum_result is not None and product_result is not None:
        print(f"Sum: {sum_result}, Product: {product_result}")
    else:
        print("Failed to get a valid response from the service.")

