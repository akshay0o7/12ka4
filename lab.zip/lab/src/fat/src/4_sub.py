#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64MultiArray

def callback(data):
    root1_real = data.data[0]
    root1_img = data.data[1]
    root2_real = data.data[2]
    root2_img = data.data[3]
    
    rospy.loginfo(f"Roots are {root1_real} + {root1_img}i and {root2_real} - {root2_img}i")

def listener():
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('chatter', Float64MultiArray, callback)


    rospy.spin()

if __name__ == '__main__':
    listener()
