#!/usr/bin/env/ python3 

import rospy 

if __name__=='__main__': 

   rospy.init_node('my_first_python_node') 

   rospy.loginfo("THis node has been started") 

   rate = rospy.Rate(10) 

   while not rospy.is_shutdown(): 

     rospy.loginfo("My name is Siddhansh and Registration Number:21BMH1074") 

   rospy.sleep() 
