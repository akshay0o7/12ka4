// Auto-generated. Do not edit!

// (in-package fat.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class addRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.a = null;
      this.b = null;
      this.c = null;
    }
    else {
      if (initObj.hasOwnProperty('a')) {
        this.a = initObj.a
      }
      else {
        this.a = 0;
      }
      if (initObj.hasOwnProperty('b')) {
        this.b = initObj.b
      }
      else {
        this.b = 0;
      }
      if (initObj.hasOwnProperty('c')) {
        this.c = initObj.c
      }
      else {
        this.c = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type addRequest
    // Serialize message field [a]
    bufferOffset = _serializer.int32(obj.a, buffer, bufferOffset);
    // Serialize message field [b]
    bufferOffset = _serializer.int32(obj.b, buffer, bufferOffset);
    // Serialize message field [c]
    bufferOffset = _serializer.int32(obj.c, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type addRequest
    let len;
    let data = new addRequest(null);
    // Deserialize message field [a]
    data.a = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [b]
    data.b = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [c]
    data.c = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'fat/addRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8e8991925bcc343091e9b8015dc05ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Request
    int32 a
    int32 b
    int32 c
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new addRequest(null);
    if (msg.a !== undefined) {
      resolved.a = msg.a;
    }
    else {
      resolved.a = 0
    }

    if (msg.b !== undefined) {
      resolved.b = msg.b;
    }
    else {
      resolved.b = 0
    }

    if (msg.c !== undefined) {
      resolved.c = msg.c;
    }
    else {
      resolved.c = 0
    }

    return resolved;
    }
};

class addResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sum_result = null;
      this.product_result = null;
    }
    else {
      if (initObj.hasOwnProperty('sum_result')) {
        this.sum_result = initObj.sum_result
      }
      else {
        this.sum_result = 0;
      }
      if (initObj.hasOwnProperty('product_result')) {
        this.product_result = initObj.product_result
      }
      else {
        this.product_result = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type addResponse
    // Serialize message field [sum_result]
    bufferOffset = _serializer.int32(obj.sum_result, buffer, bufferOffset);
    // Serialize message field [product_result]
    bufferOffset = _serializer.int32(obj.product_result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type addResponse
    let len;
    let data = new addResponse(null);
    // Deserialize message field [sum_result]
    data.sum_result = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [product_result]
    data.product_result = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'fat/addResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31bf89667e3e25110145caf6ce1dc362';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Response
    int32 sum_result
    int32 product_result
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new addResponse(null);
    if (msg.sum_result !== undefined) {
      resolved.sum_result = msg.sum_result;
    }
    else {
      resolved.sum_result = 0
    }

    if (msg.product_result !== undefined) {
      resolved.product_result = msg.product_result;
    }
    else {
      resolved.product_result = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: addRequest,
  Response: addResponse,
  md5sum() { return '072b1789e2cdc7d392fb7d1d3ee1ff28'; },
  datatype() { return 'fat/add'; }
};
