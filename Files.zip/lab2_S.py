#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def callback(data):
    try:
        a, b, c = map(float, data.data.split(','))
        result = (a + b + c) ** 2
        rospy.loginfo(f"Received values: a={a}, b={b}, c={c}, (a + b + c)^2 = {result}")
    except ValueError:
        rospy.logwarn("Received invalid data.")

def subscriber():
    rospy.init_node('input_subscriber', anonymous=True)
    rospy.Subscriber('input_values', String, callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        subscriber()
    except rospy.ROSInterruptException:
        pass

