#!/usr/bin/env python3

import rospy

if __name__=='__main__':
    rospy.init_node('my_first_python_node')
    rospy.loginfo("HELLO")
    
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
           rospy.loginfo("My name is Akshay D H and my registration number is 21BMH1041")
           rate.sleep()
           
