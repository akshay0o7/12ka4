import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class ComplexQuadraticPublisher(Node):  # Level 1 indentation
    def __init__(self):  # Level 2 indentation (inside the class)
        super().__init__('complex_quadratic_publisher')
        self.publisher_ = self.create_publisher(Float64MultiArray, 'quadratic_coefficients', 10)
        self.timer = self.create_timer(1, self.publish_coefficients)

    def publish_coefficients(self):  # Level 2 indentation (inside the class)
        coefficients = Float64MultiArray()  # Level 3 indentation (inside the method)
        # Get user input for quadratic coefficients
        a = float(input("Enter coefficient a: "))  # Level 4 indentation (inside the method)
        b = float(input("Enter coefficient b: "))  # Level 4 indentation (inside the method)
        c = float(input("Enter coefficient c: "))  # Level 4 indentation (inside the method)

        # Publish the coefficients
        coefficients.data = [a, b, c]  # Level 4 indentation (inside the method)
        self.publisher_.publish(coefficients)  # Level 4 indentation (inside the method)
        self.get_logger().info(f'Published coefficients: a = {a}, b = {b}, c = {c}')  # Level 4 indentation (inside the method)

def main(args=None):  # Level 1 indentation
    rclpy.init(args=args)
    node = ComplexQuadraticPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':  # Level 1 indentation
    main()
