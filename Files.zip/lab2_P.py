#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def publisher():
    pub = rospy.Publisher('input_values', String, queue_size=10)
    rospy.init_node('input_publisher', anonymous=True)
    rate = rospy.Rate(1)  # 1 Hz

    while not rospy.is_shutdown():
        try:
            a = float(input("Enter value for a: "))
            b = float(input("Enter value for b: "))
            c = float(input("Enter value for c: "))
        except ValueError:
            rospy.logwarn("Please enter valid numbers.")
            continue

        values_str = f"{a},{b},{c}"
        rospy.loginfo(f"Publishing values: {values_str}")
        pub.publish(values_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        publisher()
    except rospy.ROSInterruptException:
        pass

