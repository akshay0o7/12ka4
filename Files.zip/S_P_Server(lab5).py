#!/usr/bin/env python3

import rospy
from your_package_name.srv import Calculate, CalculateResponse

def handle_calculate(req):
    sum_value = req.a + req.b + req.c
    product_value = req.a * req.b * req.c
    rospy.loginfo(f"Received: a={req.a}, b={req.b}, c={req.c}")
    rospy.loginfo(f"Sum: {sum_value}, Product: {product_value}")
    return CalculateResponse(sum=sum_value, product=product_value)

def calculate_server():
    rospy.init_node('calculate_server')
    service = rospy.Service('calculate', Calculate, handle_calculate)
    rospy.loginfo("Service 'calculate' ready.")
    rospy.spin()

if __name__ == "__main__":
    calculate_server()
