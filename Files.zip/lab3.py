#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
import math

def get_coefficients():
    rospy.loginfo("Enter the coefficients for the quadratic equation (ax^2 + bx + c = 0):")
    a = float(input("Enter coefficient a: "))
    b = float(input("Enter coefficient b: "))
    c = float(input("Enter coefficient c: "))
    return a, b, c

def solve_quadratic(a, b, c):
    discriminant = b**2 - 4*a*c
    if discriminant > 0:
        root1 = (-b + math.sqrt(discriminant)) / (2 * a)
        root2 = (-b - math.sqrt(discriminant)) / (2 * a)
        return (root1, root2)
    elif discriminant == 0:
        root = -b / (2 * a)
        return (root,)
    else:
        return ()  # No real roots

def quadratic_solver():
    rospy.init_node('quadratic_solver', anonymous=True)

    # Get the coefficients from the user
    a, b, c = get_coefficients()

    if a == 0:
        rospy.logerr("Coefficient 'a' must not be zero in a quadratic equation.")
        return

    # Solve the quadratic equation
    roots = solve_quadratic(a, b, c)

    # Print the results
    if roots:
        rospy.loginfo(f"Real roots of the equation are: {roots}")
    else:
        rospy.loginfo("The equation has no real roots.")

if __name__ == '__main__':
    try:
        quadratic_solver()
    except rospy.ROSInterruptException:
        pass
        
        
        
#osrun turtlesim turtle_teleop_key
#osrun turtlesim turtlesim_node
#rosnode list
#rostopic list
#rostopic echo /turtle1/cmd_vel
