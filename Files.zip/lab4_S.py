import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import cmath

class ComplexQuadraticSubscriber(Node):  # Class definition starts here (Level 1)
    def __init__(self):  # Method inside the class (Level 2)
        super().__init__('complex_quadratic_subscriber')
        self.subscription = self.create_subscription(  # Method contents (Level 3)
            Float64MultiArray,
            'quadratic_coefficients',
            self.compute_complex_roots,
            10)
        self.subscription  # Prevent unused variable warning (Level 3)

    def compute_complex_roots(self, msg):  # Another method inside the class (Level 2)
        a, b, c = msg.data  # Inside method (Level 3)
        discriminant = b**2 - 4*a*c  # Inside method (Level 3)
        # Calculate complex roots (Level 3)
        root1 = (-b + cmath.sqrt(discriminant)) / (2*a)
        root2 = (-b - cmath.sqrt(discriminant)) / (2*a)

        # Separate real and imaginary parts (Level 3)
        real_part1, imag_part1 = root1.real, root1.imag
        real_part2, imag_part2 = root2.real, root2.imag

        # Log the results in x1 + ix2 format (Level 3)
        self.get_logger().info(f'Root 1: {real_part1} + i{imag_part1}')
        self.get_logger().info(f'Root 2: {real_part2} + i{imag_part2}')

def main(args=None):  # Main function (Level 1)
    rclpy.init(args=args)  # Inside main (Level 2)
    node = ComplexQuadraticSubscriber()  # Inside main (Level 2)
    rclpy.spin(node)  # Inside main (Level 2)
    node.destroy_node()  # Inside main (Level 2)
    rclpy.shutdown()  # Inside main (Level 2)

if __name__ == '__main__':  # Top-level check (Level 1)
    main()  # Inside the if block (Level 2)
