#!/usr/bin/env python3

import rospy
from turtlesim.srv import TeleportAbsolute
from your_package_name.srv import DrawTriangle, DrawTriangleResponse
import math

def draw_triangle(req):
    rospy.loginfo(f"Drawing a triangle with side length: {req.side_length}")
    
    side_length = req.side_length
    angle = 120  # Angle between sides for an equilateral triangle

    # Connect to turtle services
    rospy.wait_for_service('/turtle1/teleport_absolute')
    teleport = rospy.ServiceProxy('/turtle1/teleport_absolute', TeleportAbsolute)
    
    try:
        # Move the turtle to create a triangle
        x, y = 5.5, 5.5  # Starting at the center
        for i in range(3):
            teleport(x, y, 0)
            rospy.sleep(1)
            x += side_length * math.cos(math.radians(i * angle))
            y += side_length * math.sin(math.radians(i * angle))
        return DrawTriangleResponse(success=True)
    except Exception as e:
        rospy.logerr(f"Error while drawing triangle: {e}")
        return DrawTriangleResponse(success=False)

def triangle_draw_server():
    rospy.init_node('triangle_draw_server')
    service = rospy.Service('draw_triangle', DrawTriangle, draw_triangle)
    rospy.loginfo("Service 'draw_triangle' ready.")
    rospy.spin()

if __name__ == "__main__":
    triangle_draw_server()
