#!/usr/bin/env python3

import rospy
from your_package_name.srv import Calculate

def calculate_client(a, b, c):
    rospy.wait_for_service('calculate')
    try:
        calculate = rospy.ServiceProxy('calculate', Calculate)
        response = calculate(a, b, c)
        rospy.loginfo(f"Sum: {response.sum}, Product: {response.product}")
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == "__main__":
    rospy.init_node('calculate_client')
    a, b, c = 5, 3, 2  # Example inputs
    calculate_client(a, b, c)
