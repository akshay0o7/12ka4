#!/usr/bin/env python3

import rospy
from your_package_name.srv import DrawTriangle

def draw_triangle_client(side_length):
    rospy.wait_for_service('draw_triangle')
    try:
        draw_triangle = rospy.ServiceProxy('draw_triangle', DrawTriangle)
        response = draw_triangle(side_length)
        if response.success:
            rospy.loginfo("Triangle successfully drawn.")
        else:
            rospy.logwarn("Failed to draw the triangle.")
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == "__main__":
    rospy.init_node('triangle_draw_client')
    side_length = 2.0  # Example side length
    draw_triangle_client(side_length)
